import { useEffect, useRef } from 'react';

/**
 * Modal keyboard: Enter submits when valid, Escape closes.
 * Attach ref to the `.modal` element (not the backdrop).
 */
export function useModalKeyboard({ valid, onSubmit, onClose }) {
  const modalRef = useRef(null);

  useEffect(() => {
    const el = modalRef.current;
    if (!el) return;

    const firstInput = el.querySelector(
      'input:not([type="radio"]):not([readonly]), textarea, select'
    );
    if (firstInput) {
      requestAnimationFrame(() => firstInput.focus());
    }

    const onKeyDown = (ev) => {
      if (ev.key === 'Escape') {
        ev.preventDefault();
        ev.stopPropagation();
        onClose();
        return;
      }
      if (ev.key === 'Enter' && valid) {
        ev.preventDefault();
        ev.stopPropagation();
        onSubmit();
      }
    };

    el.addEventListener('keydown', onKeyDown);
    return () => el.removeEventListener('keydown', onKeyDown);
  }, [valid, onSubmit, onClose]);

  return modalRef;
}
